﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Win32;
namespace OfficePDFConversionRegisteryKeySetting
{
    class Program
    {
        static void Main(string[] args)
        {
            string path = "software\\Microsoft\\Office\\15.0\\Word\\Options";
            RegistryKey key = Registry.CurrentUser;
            RegistryKey wordPath = key.CreateSubKey(path);
            if (wordPath != null)
            {
                wordPath.SetValue("DisableConvertPdfWarning", 1);
                Console.WriteLine("Done");
            }
            else
                Console.WriteLine("Not Exist Key Folder");
            Console.ReadKey();
        }
    }
}
