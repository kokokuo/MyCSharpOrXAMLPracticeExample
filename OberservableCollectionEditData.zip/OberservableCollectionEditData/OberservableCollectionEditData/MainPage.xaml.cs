﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.IO;
using System.Linq;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;

// 空白頁項目範本已記錄在 http://go.microsoft.com/fwlink/?LinkId=234238

namespace OberservableCollectionEditData
{
    /// <summary>
    /// 可以在本身使用或巡覽至框架內的空白頁面。
    /// </summary>
    public sealed partial class MainPage : Page
    {
       

        ObservableCollection<WantedData> wantedDataCollection = new ObservableCollection<WantedData>
        {
             new WantedData{Content = "筆記本" , Price = 30},
            new WantedData{Content = "鞋子" , Price = 2000}
        };

        int selected;
        int selectedType;
        public MainPage()
        {
            this.InitializeComponent();
         

            wantedListBox2.ItemsSource = wantedDataCollection;

            selectedType = selected = -1;

        }

        /// <summary>
        /// 在此頁面即將顯示在框架中時叫用。
        /// </summary>
        /// <param name="e">描述如何到達此頁面的事件資料。Parameter
        /// 屬性通常用來設定頁面。</param>
        protected override void OnNavigatedTo(NavigationEventArgs e)
        {
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            //ObservableCollection
            wantedDataCollection.Add(new WantedData { Content = wantedText.Text, Price = Convert.ToInt32(wantedPriceText.Text) });
        }

        private void delete_Click(object sender, RoutedEventArgs e)
        {
            if (selected != -1)
                wantedDataCollection.RemoveAt(selected);
        }


        //ObeservableCollection
        private void wantedListBox2_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            selected = wantedListBox2.SelectedIndex;
            ListBoxItem selectedItem = (ListBoxItem)wantedListBox2.ItemContainerGenerator.ContainerFromIndex(wantedListBox2.SelectedIndex);
            WantedData selectedWantedData = (WantedData)selectedItem.Content;

            editText.Text = selectedWantedData.Content;
            editPriceText.Text = selectedWantedData.Price.ToString();

           
        }


        private void edit_Click(object sender, RoutedEventArgs e)
        {
             

            ListBoxItem selectedItem = (ListBoxItem)wantedListBox2.ItemContainerGenerator.ContainerFromIndex(wantedListBox2.SelectedIndex);

            WantedData selectedWantedData = (WantedData)selectedItem.Content;

            selectedWantedData.Content = editText.Text;
            selectedWantedData.Price = Convert.ToInt32(editPriceText.Text);


        }

    }

    //INotifyPropertyChanged 用來協助更新資料
    public class WantedData : INotifyPropertyChanged
    {
        string content;
        int price;
        public string Content
        {
            get { return content; }
            set
            {
                content = value;
                NotifyPropertyChanged("Content");
            }
        }
        public int Price
        {
            get { return price; }
            set
            {
                price = value;
                NotifyPropertyChanged("Price");
            }
        }

        public event PropertyChangedEventHandler PropertyChanged;
        protected void NotifyPropertyChanged(string propertyName)
        {
            if (PropertyChanged != null)
            { PropertyChanged(this, new PropertyChangedEventArgs(propertyName)); }
        }
    }
}
